package com.example.web_profile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
